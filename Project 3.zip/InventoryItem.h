/**
*Nicole Napier
*CS 210
*Project 3
*
*Inventory Item Header
*/

#ifndef Project_3_INVENTORYITEM_H
#define Project_3

#include <string>

using namespace std;

/**
 * InventoryItem class for information about a sold item.
 */
class InventoryItem {
private:
	string name;
	int quantity;
public:
	explicit InventoryItem(const string& name, int qty = 1);
	string getName();
	[[nodiscard]] int getQty() const;
};


#endif //e
